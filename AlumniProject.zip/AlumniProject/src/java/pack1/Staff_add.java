
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "Staff_add", urlPatterns = {"/Staff_add"})
public class Staff_add extends HttpServlet {

  
   

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
                
       String fname=request.getParameter("s1");
       String mname=request.getParameter("s2");
       String lname=request.getParameter("s3");
       String age=request.getParameter("sage") ;
       String gender=request.getParameter("g1");
       String dob=request.getParameter("sdate");
       String email=request.getParameter("semail");
       String mobile=request.getParameter("smob");
       String dept=request.getParameter("sdep");
       String pwd=request.getParameter("spassword");
       
         if(fname==null || fname=="" )
        {
            request.setAttribute("error1", "Enter First name");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
                    
        }
         else if(mname==null || mname=="" )
        {
            request.setAttribute("error2", "Enter midddle name");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
     
              else if(lname==null || lname=="" )
        {
            request.setAttribute("error3", "Enter Last name");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
          else if(age==null || age=="" )
        {
            request.setAttribute("error4", "Age cannot be emtpy");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
          else if(dob==null || dob=="" )
        {
            request.setAttribute("error5", "Date of birth cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
          else if(dept==null || dept=="" )
        {
            request.setAttribute("error6", "Department cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
          else if(mobile==null || mobile=="" )
        {
            request.setAttribute("error7", "Mobile number cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
            else if(mobile.length()<10 || mobile.length()>10 )
        {
            request.setAttribute("error10", "Enter valid mobile no");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
          else if(email==null || email=="" )
        {
            request.setAttribute("error8", "Email id cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
          else if(pwd==null || pwd=="" )
        {
            request.setAttribute("error9", "Password cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
        
          else if(pwd.length()<6 )
        {
            request.setAttribute("error11", "Password must be 6 character long");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_add.jsp");
            rd.include(request, response);
        }
         else
          {
        try{
            
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
          
          
            String sql =("insert into staff(Firstname,Middlename,Lastname,Age,Gender,Dateofbirth,email,mobile,Department,Password) values(?,?,?,?,?,?,?,?,?,?)");
           
            pst= con.prepareStatement(sql);
            pst.setString(1, fname);
            pst.setString(2, lname);
            pst.setString(3, mname);
            pst.setString(4, age);
            pst.setString(5, gender);
            pst.setString(6, dob);
            pst.setString(7, email);
            pst.setString(8, mobile);
            pst.setString(9, dept);
            pst.setString(10, pwd);
         
           
            pst.executeUpdate();
          
            response.sendRedirect("admin.jsp");
 
       
     }
     catch(Exception e)
     {
         System.out.println(e.getMessage());
     }
    }
    }
  

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
