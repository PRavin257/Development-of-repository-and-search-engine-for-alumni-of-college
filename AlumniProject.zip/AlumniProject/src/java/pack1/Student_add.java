
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "Student_add", urlPatterns = {"/Student_add"})
public class Student_add extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
                
       String fname=request.getParameter("n1");
       String mname=request.getParameter("n2");
       String lname=request.getParameter("n3");
       String age=request.getParameter("age") ;
       String gender=request.getParameter("r1");
       String dob=request.getParameter("date");
       String course=request.getParameter("course");
      
       String mobile=request.getParameter("mobile");
       String email=request.getParameter("email");
       String pwd=request.getParameter("password");
         if(fname==null || fname=="" )
        {
            request.setAttribute("error1", "Enter First name");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
                    
        }
         else if(mname==null || mname=="" )
        {
            request.setAttribute("error2", "Enter midddle name");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
     
              else if(lname==null || lname=="" )
        {
            request.setAttribute("error3", "Enter Last name");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
          else if(age==null || age=="" )
        {
            request.setAttribute("error4", "Age cannot be emtpy");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
          else if(dob==null || dob=="" )
        {
            request.setAttribute("error5", "Date of birth cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
          else if(course==null || course=="" )
        {
            request.setAttribute("error6", "Course cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
          else if(mobile==null || mobile=="" )
        {
            request.setAttribute("error7", "Mobile number cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
            else if(mobile.length()<10 || mobile.length()>10 )
        {
            request.setAttribute("error10", "Enter valid mobile no");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
          else if(email==null || email=="" )
        {
            request.setAttribute("error8", "Email id cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
          else if(pwd==null || pwd=="" )
        {
            request.setAttribute("error9", "Password cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
        
          else if(pwd.length()<6 )
        {
            request.setAttribute("error11", "Password must be 6 character long");
            RequestDispatcher rd= request.getRequestDispatcher("register.jsp");
            rd.include(request, response);
        }
         else
          {
        try{
            
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3307/final","root","");
          
          
            String sql =("insert into student(Firstname,Middlename,Lastname,Age,Gender,Dateofbirth,Course,Mobile,Email,Password) values(?,?,?,?,?,?,?,?,?,?)");
           
            pst= con.prepareStatement(sql);
            pst.setString(1, fname);
            pst.setString(2, mname);
            pst.setString(3, lname);
            pst.setString(4, age);
            pst.setString(5, gender);
            pst.setString(6, dob);
            pst.setString(7, course);
           
            pst.setString(8, mobile);
            pst.setString(9, email);
            pst.setString(10, pwd);
           
            pst.executeUpdate();
          
            request.setAttribute("update1", "Student Data Submitted successfully");
            RequestDispatcher rd= request.getRequestDispatcher("Student_add.jsp");
            rd.include(request, response);
       
     }
     catch(Exception e)
     {
         System.out.println(e.getMessage());
     }
       }
    }


}
