
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "placement_add", urlPatterns = {"/placement_add"})
public class placement_add extends HttpServlet {

    

 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
                
       String name=request.getParameter("cname");
       String email=request.getParameter("cemail");
       String mobile=request.getParameter("cmob");
       String position=request.getParameter("cposition") ;
       String password=request.getParameter("cpassword");
       
          if(name==null || name=="" )
        {
            request.setAttribute("error1", "Enter name of the company");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
                    
        }
         else if(email==null || email=="" )
        {
            request.setAttribute("error2", "Enter email id");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
        }
     
              else if(mobile==null || mobile=="" )
        {
            request.setAttribute("error3", "Mobile number cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
        }
                else if(mobile.length()<10 || mobile.length()>10 )
        {
            request.setAttribute("error4", "Enter valid mobile no");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
        }
          else if(position==null || position=="" )
        {
            request.setAttribute("error5", "Enter the required position");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
        }
             else if(password==null || password=="" )
        {
            request.setAttribute("error6", "Password cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
        }
        
          else if(password.length()<6 )
        {
            request.setAttribute("error7", "Password must be 6 character long");
            RequestDispatcher rd= request.getRequestDispatcher("Add_company.jsp");
            rd.include(request, response);
        }
       
       
       else
          {
      
        try{
            
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
          
          
            String sql =("insert into company(Name,email,mobile,position,password) values(?,?,?,?,?)");
           
            pst= con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, mobile);
            pst.setString(4, position);
            pst.setString(5, password);
           pst.executeUpdate();
           response.sendRedirect("admin.jsp");
 
       
     }
     catch(Exception e)
     {
         System.out.println(e.getMessage());
     }
    }}

 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
