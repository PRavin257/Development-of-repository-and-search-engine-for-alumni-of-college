
package pack1;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Asus
 */
@WebServlet(name = "Student_profile_view", urlPatterns = {"/Student_profile_view"})
public class Student_profile_view extends HttpServlet {

    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
       
          try{
            Blob image=null;
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
          
          
            String sql =("select path from student where UID=?");
            pst= con.prepareStatement(sql);
            pst.setString(1, id);
           
            ResultSet rs = pst.executeQuery();
          
        if(rs.next()){
       
        byte byteArray[] = rs.getBytes("path");
       
        System.out.println(byteArray);
        response.setHeader("expires","0");
        response.setContentType("image/gif");
        OutputStream os = response.getOutputStream();
        os.write(byteArray);
        os.flush();
        os.close();
        
    }
  
     }
     catch(Exception e)
     {
         System.out.println(e.getMessage());
     }
    }


}
