
package pack1;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author Asus
 */
@WebServlet(name = "Student_password_change", urlPatterns = {"/Student_password_change"})
public class Student_password_change extends HttpServlet {

   
    

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
   
       String email=request.getParameter("email");
       String pass=request.getParameter("pass"); 
     
         if(email==null || "".equals(email) )
        {
            request.setAttribute("error1", "Email id cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_password_change.jsp");
            rd.include(request, response);
        }
          else if(pass==null || "".equals(pass) )
        {
            request.setAttribute("error2", "Password cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_password_change.jsp");
            rd.include(request, response);
        }
        
          else if(pass.length()<6 )
        {
            request.setAttribute("error3", "Password must be 6 character long");
            RequestDispatcher rd= request.getRequestDispatcher("Student_password_change.jsp");
            rd.include(request, response);
        }
    else
          {
        try {
          
              PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
       
            String sql =("update student set Password=? where Email=?");
           
            pst= con.prepareStatement(sql);
            pst.setString(1, pass);
            pst.setString(2, email);
            pst.executeUpdate();
           
          request.setAttribute("change", "Password Changed Successfully");
            RequestDispatcher rd= request.getRequestDispatcher("Student_password_change.jsp");
            rd.include(request, response);
        } catch (Exception e) {
            out.println(e);
        }

          }
    }
}
