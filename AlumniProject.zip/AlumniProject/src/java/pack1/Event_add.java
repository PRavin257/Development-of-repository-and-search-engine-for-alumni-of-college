
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "Event_add", urlPatterns = {"/Event_add"})
public class Event_add extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
                
       String name=request.getParameter("ename");
       String guest=request.getParameter("eguest");
       String date=request.getParameter("edate");
       String time=request.getParameter("etime") ;
       
         if(name==null || name=="" )
        {
            request.setAttribute("error1", "Enter the name of event");
            RequestDispatcher rd= request.getRequestDispatcher("Add_event.jsp");
            rd.include(request, response);
                    
        }
         else if(guest==null || guest=="" )
        {
            request.setAttribute("error2", "Enter the guest name");
            RequestDispatcher rd= request.getRequestDispatcher("Add_event.jsp");
            rd.include(request, response);
        }
     
              else if(date==null || date=="" )
        {
            request.setAttribute("error3", "Enter the date of event");
            RequestDispatcher rd= request.getRequestDispatcher("Add_event.jsp");
            rd.include(request, response);
        }
          else if(time==null || time=="" )
        {
            request.setAttribute("error4", "Enter the time for event");
            RequestDispatcher rd= request.getRequestDispatcher("Add_event.jsp");
            rd.include(request, response);
        }
         
         else
          {
       
     
        try{
            
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
          
          
            String sql =("insert into events(Ename,Eguest,Edate,Etime) values(?,?,?,?)");
           
            pst= con.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, guest);
            pst.setString(3, date);
            pst.setString(4, time);
         
           
            pst.executeUpdate();
          
            response.sendRedirect("admin.jsp");
 
       
     }
     catch(Exception e)
     {
         System.out.println(e.getMessage());
     }
    }}

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
