
package pack1;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet(name = "Company_update", urlPatterns = {"/Company_update"})
public class Company_update extends HttpServlet {

    
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
           response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
      
       String name=request.getParameter("name");
       String mobile=request.getParameter("mobile") ;
       String position=request.getParameter("position");
       String email=request.getParameter("email");
        String rsd=request.getParameter("rsd");
       String red=request.getParameter("red");
        String ret=request.getParameter("ret");
    
 
    
        try {
          
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
       
            String sql =("update company set Name=?, mobile=?,position=?,Registerstartdate=?,Registerenddate=?,Registerendtime=? where Email=?");
           
            pst= con.prepareStatement(sql);
            
            pst.setString(1, name);
            pst.setString(2, mobile);
            pst.setString(3, position);
            pst.setString(4, rsd);
            pst.setString(5, red);
            pst.setString(6, ret);
            pst.setString(7, email);
           
            pst.executeUpdate();  
             request.setAttribute("update", "Data updated Successfully");
            RequestDispatcher rd= request.getRequestDispatcher("Company_update.jsp");
            rd.include(request, response);
         
         
        } catch (Exception e) {
            out.println(e);
        }
    }

  
}
