
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "Admin_login", urlPatterns = {"/Admin_login"})
public class Admin_login extends HttpServlet {

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
                String uname=request.getParameter("n1");
                String pwd=request.getParameter("n2");
        try{
             Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/final","root","");
            Statement st= con.createStatement();
          
            ResultSet rs =st.executeQuery("SELECT * FROM admin where  username='"+uname+"' and password='"+pwd+"'");
          if(rs.next()){
              response.sendRedirect("admin.jsp");
          }
          else
          {
              out.println("Wrong username and password");
          }
       
     }
     catch(Exception e)
     {
         System.out.println(e.getMessage());
     }
    }

  
}
