
package pack1;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet(name = "Student_apply_select", urlPatterns = {"/Student_apply_select"})
public class Student_apply_select extends HttpServlet {

  
  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
         String uid=request.getParameter("s");
         String comp=request.getParameter("c");
     int no=Integer.parseInt(uid);
        try {
          String act="Selected";
              PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
       
            String sql =("update studentapply set action='"+act+"' where uid='"+no+"'and company='"+comp+"'");
            System.out.print(comp);
            pst= con.prepareStatement(sql);
         
         
            pst.executeUpdate();
           
          request.setAttribute("update", "Student selected successfully");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply_view.jsp");
            rd.include(request, response);
            try{
                PreparedStatement pst1 =null;
            Class.forName("com.mysql.jdbc.Driver");
            pst1 = con.prepareStatement("select Email from studentapply where uid='"+no+"'");
            
            ResultSet rs=pst1.executeQuery();
            String email=rs.getString(10);
            System.out.print(email);
        
            }
            catch(Exception e)
            {
                System.out.print(e);
            }
        } catch (Exception e) {
         System.out.print(e);
        }

    }
}
