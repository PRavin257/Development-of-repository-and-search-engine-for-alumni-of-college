
package pack1;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet("/Staff_update")
@MultipartConfig(maxFileSize = 16177216)
public class Staff_update extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
           response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
      
       String fname=request.getParameter("n1");
       String mname=request.getParameter("n2");
       String lname=request.getParameter("n3");
       String age=request.getParameter("age") ;
       String gender=request.getParameter("r1");
       String dob=request.getParameter("date");
       String dept=request.getParameter("dept");
       String quali=request.getParameter("quali");
       String mobile=request.getParameter("mobile");
       String email=request.getParameter("email");
       
       Part part = request.getPart("file");
 
    
        try {
          
            PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
       
            String sql =("update staff set Firstname=? ,Middlename=? ,Lastname=? ,Age=? ,Gender=? ,Dateofbirth=?  ,mobile=?,Department=?,Qualification=?,image=? where email=?");
           
            pst= con.prepareStatement(sql);
            
            pst.setString(1, fname);
            pst.setString(2, mname);
            pst.setString(3, lname);
            pst.setString(4, age);
            pst.setString(5, gender);
            pst.setString(6, dob);
            pst.setString(7, mobile);
             pst.setString(8, dept);
             pst.setString(9, quali);
            InputStream is = part.getInputStream();
            pst.setBlob(10, is);
            pst.setString(11, email);
            pst.executeUpdate();  
            
           request.setAttribute("update", "Data updated Successfully");
            RequestDispatcher rd= request.getRequestDispatcher("Staff_update.jsp");
            rd.include(request, response);
        } catch (Exception e) {
            out.println(e);
        }

    }
   

    private String extractFileName(Part part) {//This method will print the file name.
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}

     

