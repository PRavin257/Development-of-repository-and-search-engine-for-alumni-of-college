
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "Student_apply_reject", urlPatterns = {"/Student_apply_reject"})
public class Student_apply_reject extends HttpServlet {

  
 

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         String uid=request.getParameter("r");
        int no=Integer.parseInt(uid);
   
        try {
          String act="Rejected";
             PreparedStatement pst =null;
            Class.forName("com.mysql.jdbc.Driver");
             Connection con= DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
       
            String sql =("update studentapply set action='"+act+"' where uid='"+no+"'");
           
            pst= con.prepareStatement(sql);
         
         
            pst.executeUpdate();
           
          request.setAttribute("update1", "Student Rejected successfully");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply_view.jsp");
            rd.include(request, response);
        } catch (Exception e) {
         System.out.print(e);
       
        }
                
       
    }

  
}
