
package pack1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


@WebServlet("/Student_apply")
@MultipartConfig
public class Student_apply extends HttpServlet {
   private static final long serialVersionUID = 1L; 

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      response.setContentType("text/html;charset=UTF-8");
     
        final Part filePart = request.getPart("file");
        String uid = request.getParameter("uid");
        String fname=request.getParameter("n1");
       String mname=request.getParameter("n2");
       String lname=request.getParameter("n3");
       String age=request.getParameter("age") ;
       String gender=request.getParameter("r1");
       String dob=request.getParameter("date");
       String course=request.getParameter("course");
       String mobile=request.getParameter("mobile");
       String email=request.getParameter("email");
       String company=request.getParameter("company");
        String marks=request.getParameter("marks");
         if(fname==null || fname=="" )
        {
            request.setAttribute("error1", "Enter First name");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
                    
        }
         else if(mname==null || mname=="" )
        {
            request.setAttribute("error2", "Enter midddle name");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
     
              else if(lname==null || lname=="" )
        {
            request.setAttribute("error3", "Enter Last name");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
          else if(age==null || age=="" )
        {
            request.setAttribute("error4", "Age cannot be emtpy");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
          else if(dob==null || dob=="" )
        {
            request.setAttribute("error5", "Date of birth cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
          else if(course==null || course=="" )
        {
            request.setAttribute("error6", "Course cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
          else if(mobile==null || mobile=="" )
        {
            request.setAttribute("error7", "Mobile number cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
            else if(mobile.length()<10 || mobile.length()>10 )
        {
            request.setAttribute("error10", "Enter valid mobile no");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
          else if(email==null || email=="" )
        {
            request.setAttribute("error8", "Email id cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
      /*      else if(company==null || company=="" )
        {
            request.setAttribute("error9", "Company name cannot be empty");
            RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
            rd.include(request, response);
        }
            else if(marks.10 )
            {
                request.setAttribute("error11", " CGPA must be less then 10");
                RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
                rd.include(request, response);
            }
     */
         else
            {
                
                InputStream pdfFileBytes = null;
                final PrintWriter writer = response.getWriter();
                
                try {
                    
                    if (!filePart.getContentType().equals("application/pdf"))
                    {
                        
                        request.setAttribute("error12", " Upload your Resume");
                        RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
                        rd.include(request, response);
                        return;
                    }
                    
                    else if (filePart.getSize()>1582000 ) { //2mb
                        {
                        request.setAttribute("error13", " File size is big");
                        RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
                        rd.include(request, response);
                        
                        return;
                    }
                    }
                    
                    pdfFileBytes = filePart.getInputStream();  // to get the body of the request as binary data
                    
                    final byte[] bytes = new byte[pdfFileBytes.available()];
                    pdfFileBytes.read(bytes);  //Storing the binary data in bytes array.
                    
                    Connection  con=null;
                    Statement stmt=null;
                    
                    try {
                        Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:4306/final","root","");
                    } catch (Exception e) {
                        System.out.println(e);
                        System.exit(0);
                    }
                    
                    
                    
                    int success;
                    PreparedStatement pstmt = con.prepareStatement("insert into studentapply(uid,Firstname,Middlename,Lastname,Age,Gender,Dob,Course,Mobile,Email,company,marks,resume) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    
                    pstmt.setString(1, uid);
                    pstmt.setString(2, fname);
                    pstmt.setString(3, mname);
                    pstmt.setString(4, lname);
                    pstmt.setString(5, age);
                    pstmt.setString(6, gender);
                    pstmt.setString(7, dob);
                    pstmt.setString(8, course);
                    pstmt.setString(9, mobile);
                    pstmt.setString(10, email);
                    pstmt.setString(11, company);
                    pstmt.setString(12, marks);
                    pstmt.setBytes(13, bytes);
                    success = pstmt.executeUpdate();
                    
                    if(success>=1)
                    {     request.setAttribute("error14", "Record submited successfully");
                    RequestDispatcher rd= request.getRequestDispatcher("Student_apply.jsp");
                    rd.include(request, response);
                    }
                    con.close();
                    
                    
                    
                } catch (FileNotFoundException fnf) {
                    writer.println("You  did not specify a file to upload");
                    writer.println("<br/> ERROR: " + fnf.getMessage());
                    
                } catch (Exception e) {
                    e.printStackTrace();
                    writer.println("insert error");
                    System.out.print(e);
                }
                finally {
                    
                    if (pdfFileBytes != null) {
                        pdfFileBytes.close();
                    }
                    if (writer != null) {
                        writer.close();
                    }
                }
            }}}
    


