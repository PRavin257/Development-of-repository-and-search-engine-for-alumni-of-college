
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Placement_forgot", urlPatterns = {"/Placement_forgot"})
public class Placement_forgot extends HttpServlet {

   

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
        String email = request.getParameter("email");
            String pass = request.getParameter("pass");
            String cnfpass =request.getParameter("cnfpass");
        if(email==null || email=="")
        {
            request.setAttribute("error", "Enter email id");
            RequestDispatcher rd= request.getRequestDispatcher("Placement_forg.jsp");
            rd.include(request, response);
                    
        }
     
           else if(pass==null || pass=="")
        {
            request.setAttribute("error1", "Password can't be blank");
            RequestDispatcher rd= request.getRequestDispatcher("Placement_forg.jsp");
            rd.include(request, response);
        }
              else if(cnfpass==null || cnfpass=="")
        {
            request.setAttribute("error2", "Confirm Password can not be blank");
            RequestDispatcher rd= request.getRequestDispatcher("Placement_forg.jsp");
            rd.include(request, response);
        }
                 else if(pass != cnfpass)
        {
            request.setAttribute("error3", "Password does not match");
            RequestDispatcher rd= request.getRequestDispatcher("Placement_forg.jsp");
            rd.include(request, response);
        }
        
     else
        {
        try {
            

            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:4306/final", "root", "");
            String dbemail = null;

            PreparedStatement ps = null;
            ps = con.prepareStatement("select * from company where email=?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                dbemail = rs.getString("email");
            }

            if (email.equals(dbemail)) {
                ps = con.prepareStatement("update company set password=? where email=?");
                ps.setString(2, email);
                ps.setString(1, pass);
                ps.executeUpdate();
              
                response.sendRedirect("placement_login.jsp");
            } 
            else {
                response.sendRedirect("Placement_forg.jsp?msg=invalidemail");
            }
        } catch (Exception e) {
            System.out.print(e);
            response.sendRedirect("Placement_forg.jsp?msg=exception");
        }
    
                
        }
    }
}
